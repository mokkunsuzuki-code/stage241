#!/usr/bin/env python3
import json
import subprocess
import sys
import os
import yaml

def run(cmd: str) -> str:
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(result.stderr)
        sys.exit(1)
    return result.stdout

def main() -> None:
    if len(sys.argv) != 2:
        print("usage: verify_external_policy.py <artifact>")
        sys.exit(1)

    artifact = sys.argv[1]

    with open("policy/policy.yaml", "r", encoding="utf-8") as f:
        policy = yaml.safe_load(f)

    repo = policy["identity"]["repository"]
    workflow = policy["identity"]["workflow"]

    os.makedirs("out/external_verification", exist_ok=True)

    print("[INFO] verifying provenance...")
    prov = run(
        f'''gh attestation verify "{artifact}" \
  --repo "{repo}" \
  --signer-workflow "{repo}/{workflow}" \
  --format json'''
    )

    print("[INFO] verifying sbom...")
    sbom = run(
        f'''gh attestation verify "{artifact}" \
  --repo "{repo}" \
  --signer-workflow "{repo}/{workflow}" \
  --predicate-type "https://spdx.dev/Document/v2.3" \
  --format json'''
    )

    with open("out/external_verification/provenance.json", "w", encoding="utf-8") as f:
        f.write(prov)

    with open("out/external_verification/sbom.json", "w", encoding="utf-8") as f:
        f.write(sbom)

    result = {
        "artifact": artifact,
        "repository": repo,
        "workflow": workflow,
        "result": "pass"
    }

    with open("out/external_verification/result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("[OK] external verification passed")
    print("[OK] wrote: out/external_verification/provenance.json")
    print("[OK] wrote: out/external_verification/sbom.json")
    print("[OK] wrote: out/external_verification/result.json")

if __name__ == "__main__":
    main()
